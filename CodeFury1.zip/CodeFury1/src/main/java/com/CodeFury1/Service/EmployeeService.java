package com.CodeFury1.Service;

import java.util.List;

import com.CodeFury1.Dao.EmployeeDao;
import com.CodeFury1.Dao.EmployeeDaoInterface;
import com.CodeFury1.Entity.Account;
import com.CodeFury1.Entity.Customer;
import com.CodeFury1.Entity.Employee;

public class EmployeeService implements EmployeeServiceInterface{
	
	private EmployeeDaoInterface ed;
	
	public EmployeeService()
	{
		ed=new EmployeeDao();
	}
	
	@Override
	public Employee loginEmployeeService(Employee e) {
		Employee e1 = ed.loginEmployeeDao(e);
		return e1;
	}

	@Override
	public int insertCustomerandAccount(Customer c, Account a) {
		int i = ed.insertCustomerandAccountDao(c,a);
		return i;
	}

	@Override
	public int insertAccount(Account a) {
		int i = ed.insertAccountDao(a);
		return i;
	}

	@Override
	public List<Integer> fetchcustid() {
		List<Integer> l = ed.fetchcustid();
		return l;
	}

}
