package com.CodeFury1.openAccountService;

import java.util.List;

import com.CodeFury1.Entity.CustomerDetails;

public interface ServiceInterface {
	public List<CustomerDetails> displayCustomer();
	public int checkPhone(CustomerDetails c);
	

}
