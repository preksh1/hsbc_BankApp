package com.CodeFury1.openAccountService;

import java.util.List;

import com.CodeFury1.Entity.CustomerDetails;
import com.CodeFury1.openAccountDao.Dao;
import com.CodeFury1.openAccountDao.DaoInterface;

public class Service implements ServiceInterface{

	private DaoInterface di=null;
	public Service() {
		
		try {
			di=new Dao();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	@Override
	public List<CustomerDetails> displayCustomer() {
		// TODO Auto-generated method stub
		List<CustomerDetails> l=null;
		try {
			l=di.displayCustomer();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return l;
	}

	@Override
	public int checkPhone(CustomerDetails c) {
		int i=0;
		try {
			i=di.checkPhone(c);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return i;
	}

	
}
