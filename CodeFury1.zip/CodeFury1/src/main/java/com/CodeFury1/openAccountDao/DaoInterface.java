package com.CodeFury1.openAccountDao;

import java.sql.ResultSet;
import java.util.List;

import com.CodeFury1.Entity.AccountDetails;
import com.CodeFury1.Entity.CustomerDetails;

public interface DaoInterface {
	//public int checkNewCustomer(Integer custId) throws Exception;
	public List<CustomerDetails> displayCustomer() throws Exception ;
	public int checkPhone(CustomerDetails c) throws Exception;
}
